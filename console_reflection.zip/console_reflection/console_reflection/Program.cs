﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace console_reflection
{
    class Program
    {
        static void Main(string[] args)
        {

            XYZ obj = new XYZ();
            obj.call();

            /*
            Type t = typeof(test);// loading method
            Console.WriteLine(t.Assembly.FullName);
            Console.WriteLine(t.FullName);
            MethodInfo[] m = t.GetMethods();
            foreach(MethodInfo method in m)
            {
                Console.WriteLine(method.Name);

            }

            Object obj = Activator.CreateInstance(t);// object is created for the reflection
            foreach(MethodInfo meth in m)
            {
                if (meth.GetParameters().Length == 0)
                {
                    object ret = meth.Invoke(obj, null);// invokes the object of type t to get the method and their parameter
                    Console.WriteLine("return value :" + ret);
                }
            }

    */


            Console.ReadLine();



        }
    }
}
