﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace console_reflection
{
    class test
    {
       public string getdata1()
        {
            return "getdata1";

        }

        public string getdata2()
        {
            return "getdata2";

        }

        public string getdata3()
        {
            return "getdata3";
        }






    }
}
