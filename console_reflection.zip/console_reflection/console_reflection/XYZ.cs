﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace console_reflection
{
    class XYZ
    {
        [Obsolete("it is not in use ,instead go to getcall function",true)]//forcing the function to go to another method instead of exsisting function.
        public void call()
        {
            Console.WriteLine("call function");
        }
        public void getcall()
        {
            Console.WriteLine("New getcall function");
        }






    }
}
