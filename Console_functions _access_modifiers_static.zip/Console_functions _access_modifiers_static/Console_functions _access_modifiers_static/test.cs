﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_functions__access_modifiers_static
{
    class test
    {
        public void call1(int a)//call by value 
        {
            a = 200;
        }
        public void call2(ref int a)//call by reference
        {
            a = a + 200;
        }
        public void call3(out int a)//call by out
        {
            //a=a+10;error
            a = 200;
        }


    }
}
