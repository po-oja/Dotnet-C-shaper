﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_functions__access_modifiers_static
{
   partial class XYZ
    {

        public void call3()
        {

        }
        public void call4()
        {

        }
    }
}
