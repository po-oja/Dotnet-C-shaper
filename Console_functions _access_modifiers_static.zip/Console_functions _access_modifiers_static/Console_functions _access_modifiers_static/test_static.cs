﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_functions__access_modifiers_static
{
    class test_static
    {
        static test_static()//static constructor and the are called only once 
        {
            Console.WriteLine("static constructor");
        }
        public test_static()
        {
            test_static.count = 10;
        }




        public static int count;//default 0 static variable will be called by only class not by object

        public static void call()
        {
            Console.WriteLine("static funtion");
        }
    }
}
