﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_functions__access_modifiers_static
{
   partial class XYZ  // partial class where the two class will be having same class name and methods are divided among them and methods are called
    {

        public void call1()
        {

        }
        public void call2()
        {

        }
    }
}
