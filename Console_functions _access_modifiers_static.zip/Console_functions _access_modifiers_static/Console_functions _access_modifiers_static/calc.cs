﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_functions__access_modifiers_static
{
    class calc
    {

        public int addnumbers(int n1,int n2)
        {
            return n1 + n2;

        }
        public int addnumbers(int n1,int n2,int n3)
        {
            return n1 + n2 + n3;
        }
        public double addnumbers(double d1,double d2)
        {
            return d1 + d2;
        }
        public double addnumbres(int n1,double d2)
        {
            return n1 + d2;
        }
        public double addnumbres(double d1,int n2)
        {
            return d1 + n2;
        }
    }
}
