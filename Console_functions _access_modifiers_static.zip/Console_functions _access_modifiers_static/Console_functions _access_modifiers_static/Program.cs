﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_functions__access_modifiers_static
{
    class Program
    {
        static void Main(string[] args)
        {
            test_static obj = new test_static();
            Console.WriteLine(test_static.count);
            test_static.count = test_static.count+10;/// classname.static varibles syntax
            Console.WriteLine(test_static.count);
            test_static.count = 30;
            Console.WriteLine(test_static.count);
            test_static.call();//classname.static function name syntax
           
           
            Console.ReadLine();



            /*XYZ obj1 = new XYZ();
           // obj1.call all the 4 methods which are defined can be accessed

         
            
            
            
            
            
            
            //  test obj = new test();
            int i = 100;
           // obj.call1(i);
            Console.WriteLine(i);
  






           /* int x1 = Convert.ToInt32(null);//0 is x value 
            //float.Parse();tofloat is not there so the parse is used to convert the value into float
            int x2 = int.Parse(null);//runtime error,only string to integer
            int n1 = 100;
            int n2 = 200;
            int n3 = 300;
            double d1 = 10.2;
            double d2 = 7.0;
            calc obj = new calc();
            int r1 = obj.addnumbers(n1, n2);
            int r2 = obj.addnumbers(n1, n2, n3);
            double r3 = obj.addnumbers(d1, d2);
            double r4 = obj.addnumbers(d1, n2);
            double r5 = obj.addnumbers(n1, d2);


            Console.WriteLine(r1);
            Console.WriteLine(r2);
            Console.WriteLine(r3);*/



        }
    }
}
