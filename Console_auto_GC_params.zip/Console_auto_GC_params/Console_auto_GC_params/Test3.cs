﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_auto_GC_params
{
    class Test3
    {
        public void call(params int[] marks)
        {
            foreach(int m in marks)
            {
                Console.WriteLine(m);
            }
        }







    }
}
