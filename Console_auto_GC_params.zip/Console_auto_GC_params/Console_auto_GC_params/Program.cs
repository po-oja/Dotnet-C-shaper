﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_auto_GC_params
{
    class Program
    {
        static void Main(string[] args)
        {

           // int[] array = { 10, 20, 30, 40, 50 };
            Test3 obj1 = new Test3();
            int[] a = new int [5];
            obj1.call(11,27,45,57,34,47,48,47,89);




            //Test2 obj1 = new Test2();

   /*
            Test2 obj = null;
            int i = 0;
            while(i<5)
            {
               obj  = new Test2();
                //obj1 = null;
                i++;
            }
            GC.Collect();
            */


            Console.ReadLine();
        }
    }
}
