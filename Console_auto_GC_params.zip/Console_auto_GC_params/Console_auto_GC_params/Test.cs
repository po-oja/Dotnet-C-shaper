﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_auto_GC_params
{
    class Test
    {
        public int studentid { get; } = 1;
        public string studentname { get; set; }

        private static int count = 100;
        public Test(string studentname)
        {
            this.studentid = ++Test.count;
            this.studentname = studentname;
        }




    }
}
