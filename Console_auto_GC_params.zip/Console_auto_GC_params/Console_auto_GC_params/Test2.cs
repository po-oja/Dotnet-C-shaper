﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_auto_GC_params
{
    class Test2
    {
        public int id { get; }
        public string name { get; set; }

        private static int count=100;
        public Test2()
        {
            Console.WriteLine("constructor");
            this.id = ++Test2.count;
        }

        ~Test2()
        {
            Console.WriteLine("destructor");// finalize function
        }



    }
}
