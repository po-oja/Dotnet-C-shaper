﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface
{
    class productbook :iproduct //implimenting interface
    {
        private int bookid;
        private string bookname;
        private string authorname;
        private int bookprice;
        private int noofpages;

        public productbook(int bookid,string bookname,string authorname,int bookprice,int noofpages)
        {
            this.bookid = bookid;
            this.bookname = bookname;
            this.authorname = authorname;
            this.bookprice = bookprice;
            this.noofpages = noofpages;
        }

        public int getproductprice()
        {
            return this.bookprice;

        }

        public string getproductname()
        {
            return this.bookname;
        }

        public int getproductid()
        {
            return this.bookid;
        }
    }
}
