﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface
{
    class order
    {
        public void addproduct(iproduct p)
        {
            int price = p.getproductprice();
            string name = p.getproductname();
            int id = p.getproductid();
            Console.WriteLine("product ID :" + id);
            Console.WriteLine("product name:" + name);
            Console.WriteLine("product price:" + price);
        }



    }
}
