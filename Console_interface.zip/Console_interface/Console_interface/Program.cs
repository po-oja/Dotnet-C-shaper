﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface
{
    class Program
    {
        static void Main(string[] args)
        {
            productbook objb = new productbook(1, "c#", "ms", 2000, 1000);
            Mobile objm = new Mobile(1010, "oneplus", 35000, "oneplus");


            Testing t = new Testing();
            t.product(objm);

            order o1 = new order();
            o1.addproduct(objb);

            order o2 = new order();
            o2.addproduct(objm);
            Console.ReadLine();




        }
    }
}
