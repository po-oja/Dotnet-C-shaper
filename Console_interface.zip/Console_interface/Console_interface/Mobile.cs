﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface
{
    class Mobile :iproduct,IproductTesting
    {
        private int mobileid;
        private string mobilename;
        private int mobilepice;
        private string mobilecompany;



        public Mobile(int moblieid,string mobilename,int mobileprice,string mobilecompany)
        {
            this.mobileid = mobileid; ;
            this.mobilename = mobilename;
            this.mobilepice = mobileprice;
            this.mobilecompany = mobilecompany;

        }
        public void start()
        {
            Console.WriteLine("mobile started");


        }
        public void stop()
        {
            Console.WriteLine("mobile stopped");
        }

        public int getproductprice()
        {
            return this.mobilepice;
        }

        public string getproductname()
        {
            return this.mobilename;
        }

        public int getproductid()
        {
            return this.mobileid;
        }
    }
}
