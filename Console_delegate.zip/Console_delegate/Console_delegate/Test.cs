﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_delegate
{
    class Test
    {
        public delegate void del(string str);//type to hold a function address 

        public void call(string str)
        {
            Console.WriteLine("call:" + str);
        }
        public void getdata(string s)
        {
            Console.WriteLine("getdata:" + s);
        }


    }
}
