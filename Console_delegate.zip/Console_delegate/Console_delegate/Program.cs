﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_delegate
{
    class Program
    {

        public static void getinfo(string s)
        {
            Console.WriteLine("static function");
        }



        static void Main(string[] args)
        {
            Test obj = new Test();
            Test.del d = new Test.del(obj.call);// d holding the address of the fuction call
                                                // d += obj.getdata;// delegate is holding another address(multicaste)
            d += Program.getinfo;
            //  d -= obj.getdata;// remove the function not to be called

            d += delegate (string s)
              {
                  Console.WriteLine(" anonymous function"+ s);
              };// for anonymous there should be;

            d += (s) => Console.WriteLine("Lambda expression" + s);

            d("hello");
            Console.ReadLine();




        }
    }
}
