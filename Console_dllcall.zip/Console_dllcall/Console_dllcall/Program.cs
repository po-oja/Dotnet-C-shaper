﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_dllcall
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter no of days");
            int nooddays = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter per day salary");
            int perdaysalary = Convert.ToInt32(Console.ReadLine());
            Testlibrary.Test dll = new Testlibrary.Test();
            int salary = dll.getsalary(perdaysalary, nooddays);
            Console.WriteLine("salary:" + salary);
            Console.ReadLine();
        }
    }
}
