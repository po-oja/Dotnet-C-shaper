﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_jagged_array_ename_var_dynamic
{
    class test
    {
        public int? i;//? is a nullable value which doesnot allow to take defualt value.
        public bool? status;
        public string name;//null is default 
    }
}
