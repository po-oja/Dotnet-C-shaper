﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_jagged_array_ename_var_dynamic
{
    enum payment_type
    {
        COD,netbanking=2,debitcard,EMI
    }
}
