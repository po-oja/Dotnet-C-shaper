﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_jagged_array_ename_var_dynamic
{
    class Program
    {
        static void Main(string[] args)
        {
            test t = new test();
            t.i = 200;
            Console.WriteLine(t.i);
            t.i = null;
            Console.WriteLine(t.i);
            Console.WriteLine(t.status);
            Console.WriteLine(t.name);





           /* var i = 100;//compile time 
            dynamic d = 1000;//run time d is called as integer
            string s2 = d.Tostring();


            string s1 = i.ToString();
            i = 200;
            var str = "abc";*/
           // Console.WriteLine(i);
            //Console.WriteLine(str);






            /*
            payment_type p = payment_type.netbanking;
            Console.WriteLine(p);
            Console.WriteLine(Convert.ToInt32(p));*/







            /*
            int[][] jagged = new int[3][];
            jagged[0] = new int[3];
            jagged[1] = new int[2];
            jagged[2] = new int[4];


            jagged[0][0] = 20;
            jagged[0][1] = 33;
            jagged[0][2] = 66;

            jagged[1][0] = 77;
            jagged[1][1] = 45;

            jagged[2][0] = 87;
            jagged[2][1] = 46;
            jagged[2][2] = 73;
            jagged[2][3] = 90;

            int x = jagged[1][1];
            Console.WriteLine(x);
            for(int c=0;c<jagged.Length;c++)
            {
                for(int i=0;i<jagged[c].Length;i++)
                { Console.WriteLine(jagged[c][i]); }
            }*/


            Console.ReadLine();
        }
    }
}
