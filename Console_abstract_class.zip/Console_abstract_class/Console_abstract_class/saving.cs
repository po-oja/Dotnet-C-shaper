﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_abstract_class
{
    class saving :account
    { 
        public saving(string customername,int accountbalance)
           : base(customername,accountbalance)
        {
            Console.WriteLine("saving object constructor");
        }

        public override void deposite(int amt)
        {
            this.accountbalance = this.accountbalance + amt + 100;
        }

        public override void withdraw(int amt)
        {
            this.accountbalance = this.accountbalance - amt - 10;
        }
    }
}
