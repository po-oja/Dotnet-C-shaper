﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_abstract_class
{
    abstract class account
    {
        protected int accountid;
        protected string customername;
        protected int accountbalance;
        protected static int count;
        public account(string customername,int accountbalance)
        {
            this.accountid = ++account.count;
            this.customername = customername;
            this.accountbalance = accountbalance;
            Console.WriteLine("account class object constructor");
        }
        public int paccountid { get { return this.accountid; } }
        public string pcustomername { get { return this.customername; } }

        public int getbalance()
        {
            return this.accountbalance;
        }
        public void stoppayment(int cheaqueno)
        {
            Console.WriteLine("payment is stopped ,ref cheque no=:" + cheaqueno);
        }
        public abstract void deposite(int amt);
        public abstract void withdraw(int amt);



    }
}
