﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_abstract_class
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter customer name");
            string name = Console.ReadLine();
            Console.WriteLine("enter the accountbalance");
            int balance = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter the type of account");
            string type = Console.ReadLine();

            account a = null;
            if(type=="saving")
            {
                a = new saving(name,balance);
            }
            else if(type=="current")
            {
                a = new current(name,balance);
            }

            if(a!=null)
            {
                Console.WriteLine(a.paccountid);
                Console.WriteLine(a.pcustomername);
                int accbalance = a.getbalance();
                Console.WriteLine("balance=" + accbalance);
                Console.WriteLine("Enter an amount to deposit");
                int amt = Convert.ToInt32(Console.ReadLine());
                a.deposite(amt);
                accbalance = a.getbalance();
                Console.WriteLine("new balance:" + accbalance);
                Console.WriteLine("enter an amount to withdraw");
                amt = Convert.ToInt32(Console.ReadLine());
                a.withdraw(amt);
                accbalance = a.getbalance();
                Console.WriteLine("new balance:" + accbalance);
                a.stoppayment(34);

             
            }
            Console.ReadLine();





        }
    }
}
