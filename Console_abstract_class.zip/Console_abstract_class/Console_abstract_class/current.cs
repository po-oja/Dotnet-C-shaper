﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_abstract_class
{
    class current:account
    {
        public current(string customername,int accountbalance)
            :base(customername,accountbalance)
        {
            Console.WriteLine("current object constructor");
        }

        public override void deposite(int amt)
        {
            this.accountbalance = this.accountbalance + amt;
        }

        public override void withdraw(int amt)
        {
            this.accountbalance = this.accountbalance - amt;
        }
    }
}
