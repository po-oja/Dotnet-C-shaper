﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop1
{
    class Program
    {
        static void Main(string[] args)
        {

            Customer obj = new Customer(1, "abc", 24, "tum");//object calling a constructor and it is called only once
            string name = obj.GetName();
            string city = obj.GetCity();
            int age = obj.GetAge();

            Console.WriteLine("name=" + name);
            Console.WriteLine("City=" + city);
            Console.WriteLine("Age=" + age.ToString());
            obj.updateAge(30);
            age = obj.GetAge();

            Console.WriteLine("Upadte age="+age.ToString());
            Console.ReadLine();
         

        }
    }
}
