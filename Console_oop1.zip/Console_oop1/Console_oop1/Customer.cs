﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop1
{
    class Customer
    {
        private int customerID;
        private string customerName;
        private int customerAge;
        private string customerCity;//actual variables

        public Customer(int customerID, string customerName, int customerAge, string customerCity)// as many objects are created that many times the constuctors are called
        {
            this.customerID = customerID;//constructor local variable (on the right side)
            this.customerName = customerName;//this keyword is used to define the self variables
            this.customerAge = customerAge;
            this.customerCity = customerCity;
            Console.WriteLine("object constructor called");
        }
        public string GetName()//getting the name from user
        {
            return this.customerName;
        }
        public string GetCity()
        {
            return this.customerCity;
        }
        public int GetAge()
        {
            return this.customerAge;

        }
        public void updateAge(int age)//update 
        {
            this.customerAge = age;
        }






    }
}
