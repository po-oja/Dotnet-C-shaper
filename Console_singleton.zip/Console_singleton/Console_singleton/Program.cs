﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_singleton
{
    class Program
    {
        static void Main(string[] args)
        {

            manager m1 = manager.getmanager();
            manager m2 = manager.getmanager();
            

            if(m1==m2)
            {
                Console.WriteLine("singleton object");
            }
            else
            {
                Console.WriteLine("not an singleton object");
            }
            Console.ReadLine();
        }
    }
}
