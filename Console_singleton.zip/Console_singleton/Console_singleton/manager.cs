﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_singleton
{
    class manager
    {
        private int managerid;
        private string managername;
        private manager( int managerid,string managername)
        {
            this.managerid = managerid;
            this.managername = managername;
        }
         public int pmangerid
        {
            get { return this.managerid; }
        }
        public string pmangername
        {
            get
            {
                return this.managername;
            }

        }
        static manager m = null;// to get the single object so intialized to null and static keyword for one copy
        public static manager getmanager()//return type is manager so its manager
        {
            if (m == null)
            {
                m = new manager(100, "abc");
            }
            return m;
        }




    }
}
