﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_overriding
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter your name");
            string name = Console.ReadLine();
            Console.WriteLine("enter your salary");
            double salary = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("enter the type of the employee");
            string type = Console.ReadLine();

            employee obj = null;// if the user as not typed the correct employee type 
            if(type=="employee")
            {
                obj = new employee(name, salary);
            }
            else if(type=="contract")
            {
                obj = new employee_contract(name, salary);
            }
            else if(type=="trainee")
                    {
                obj = new employee_training(name, salary);
            }

            if (obj != null)
            {
                Console.WriteLine("Employee ID   " + obj.pemployeeid);
                Console.WriteLine("Employee name  " + obj.pemployeename);
                Console.WriteLine("Employee salary  " + obj.pemployeesalary);

                string work = obj.getwork();
                Console.WriteLine("work detail" + work);

                Console.WriteLine("Enter the number of days");
                int days = Convert.ToInt32(Console.ReadLine());

                double monthsalary = obj.getsalary(days);
                Console.WriteLine("month salary" + monthsalary);

            }




            Console.ReadLine();








        }
    }
}
