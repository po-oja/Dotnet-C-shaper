﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_overriding
{
    class employee
    {
        protected int employeeid;
        protected string employeename;
        protected double employeesalary;
        protected static int count = 1000;

        public employee(string employeename,double employeesalary)
        {
            this.employeeid = ++employee.count;
            this.employeename = employeename;
            this.employeesalary = employeesalary;

        }

        public int pemployeeid { get { return this.employeeid; } }
        public string pemployeename { get { return this.employeename; } }
        public double pemployeesalary { get { return this.employeesalary; } }


        public string getwork()
        {
            return "dotnet developer";
        }

        public virtual double getsalary (int days)// virtual keyword is used to call the derived class function by searching override keyword in drived class
        {
            int bonus = 2000;
            double tds = this.employeesalary*0.1;
            double salary = this.employeesalary / 30 * days + bonus - tds;
            return salary;
        }




    }
}
