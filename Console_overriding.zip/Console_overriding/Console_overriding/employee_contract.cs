﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_overriding
{
    class employee_contract:employee
    {
        public employee_contract(string employeename,double employeesalary)
            :base(employeename,employeesalary)
        {
            Console.WriteLine("employee contract object constructor");
        }
        public override double getsalary(int days)//the method overrided by the base class should named overide to call this particular method when the object is created for the derived
        {
            double salary = this.employeesalary / 30 * days;
            return salary;
        }









    }
}
