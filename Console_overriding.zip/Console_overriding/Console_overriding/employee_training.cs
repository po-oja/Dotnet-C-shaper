﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_overriding
{
    class employee_training:employee
    {


        public employee_training(string employeename,double employeesalary)
            :base (employeename,employeesalary)
        {
            Console.WriteLine("object of trainee employee");
        }

        public override double getsalary(int days)// override is acting as both override and vitrual behavior
        {
            return 1000;
               
        }

    }
}
