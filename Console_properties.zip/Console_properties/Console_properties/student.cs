﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_properties
{
    class student
    {
        private int studentID;
        private string studentName;
        private int studentMarks;
        private static int count= 1000;

        public student(string studentName,int studentMarks)
        {
            //student.count++;
            this.studentID = ++student.count;
            this.studentName = studentName;
            this.studentMarks = studentMarks;
        }

        public int pstudentID//property
        {
            get
            {
                return this.studentID;
            }
        }
        public string pstudentName
        {
            get
            {
                return this.studentName;
            }
            set
            {
                if (value.Length != 0)
                {
                    this.studentName = value;
                }
            }
        }

        public int pstudentMarks
        {
            get
            {
                return this.studentMarks;
            }
            set
            {
                if(value >=0 && value<=100)
                {
                    this.studentMarks = value;
                }
            }
        }


    }
}
