﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_properties
{
    class Program
    {
        static void Main(string[] args)
        {

            student obj = new student("abc", 65);
            Console.WriteLine(obj.pstudentID);//the property is called as obj.propertyname and get is called in this way
            Console.WriteLine(obj.pstudentName);
            Console.WriteLine(obj.pstudentMarks);
            int id = obj.pstudentID;
            Console.WriteLine("student id=" + id);
            obj.pstudentName = "john";
            obj.pstudentMarks = 1001;
            Console.WriteLine(obj.pstudentName);
            obj.pstudentMarks = 10;
            Console.WriteLine(obj.pstudentMarks);

            Console.ReadLine();










        }
    }
}
