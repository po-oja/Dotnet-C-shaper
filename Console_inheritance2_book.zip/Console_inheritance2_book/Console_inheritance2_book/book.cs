﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_inheritance2_book
{
    class book
    {
        protected int bookid;
        protected string bookname;
        protected string author;
        protected int price;
        protected int numofpage;

        public book(int bookid,string bookname,string author,int price,int numofpage)
        {
            this.bookid = bookid;
            this.bookname = bookname;
            this.author = author;
            this.price = price;
            this.numofpage = numofpage;
        }
        public int pbookid
        {
            get
            {
                return this.bookid;
            }
        }
        public string pbookname
        {
            get
            {
                return this.bookname;
            }
                }
        public string pauthor
        {
            get
            {
                return this.author;
            }
        }
        public int pprice
        {
            get
            {
                return this.price;
            }
        }
        public int ppage
        {
            get
            {
                return this.numofpage;
            }
        }







    }
}
