﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_inheritance2_book
{
    class Program
    {
        static void Main(string[] args)
        {
            book obj = new book(101, "megaliving", "robin", 450, 300);
            Console.WriteLine(obj.pbookid);
            Console.WriteLine(obj.pbookname);
            Console.WriteLine(obj.pauthor);
            Console.WriteLine(obj.pprice);
            Console.WriteLine(obj.ppage);
            Console.WriteLine("******************************");
            Ebook obj1 = new Ebook(102, "wingsoffire", "APJ", 200, 500,40,"pdf");
            Console.WriteLine(obj1.pbookid);
            Console.WriteLine(obj1.pbookname);
            Console.WriteLine(obj1.pauthor);
            Console.WriteLine(obj1.pprice);
            Console.WriteLine(obj1.ppage);
            Console.WriteLine(obj1.psize);
            Console.WriteLine(obj1.pformat);

            Console.ReadLine();





        }
    }
}
