﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_inheritance2_book
{
    class Ebook :book
    {
        private int size;
        private string format;

        public Ebook(int bookid,string bookname,string author,int price,int numofpage,int size,string format)
            :base(bookid,bookname,author,price,numofpage)
        {
            this.size = size;
            this.format = format;

        }

        public int psize
        {
            get
            {
                return this.size;
            }
        }
        public string pformat
        {
            get
            {
                return this.format;
            }
        }




    }
}
