﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_LiNQ
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> emplist = new List<Employee>();
            Employee e1 = new Employee();
            e1.employeeid = 1;
            e1.employeename = "pooja";
            e1.employeesalary = 10000;
            e1.employeecity = "chennai";


            Employee e2 = new Employee();
            e2.employeeid = 2;
            e2.employeename = "pankaja";
            e2.employeesalary = 20000;
            e2.employeecity = "BGL";

            Employee e3 = new Employee();
            e3.employeeid = 3;
            e3.employeename = "prabhu";
            e1.employeesalary = 30000;
            e1.employeecity = "Tumkur";


            emplist.Add(e1);
            emplist.Add(e2);
            emplist.Add(e3);


            var q = from e in emplist
                    where e.employeesalary > 20000
                    orderby e.employeename descending
                    select e;

            var l = emplist.Where(e => e.employeesalary > 20000);//lamda expression

            foreach (var ee in l)
            {
                Console.WriteLine(ee.employeeid + " " + ee.employeename);
            }

            Console.ReadLine();
        }
    }
}
