﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Console_collection_genric
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> names = new Dictionary<int, string>();
            names.Add(1, "john");
            names.Add(2, "peter");
            names.Add(3, "david");
            names.Add(100, "rosy");

            foreach(KeyValuePair<int,string> kv in names)
            {
                Console.WriteLine(kv.Key + "  " + kv.Value);
            }
            foreach(string v in names.Values)
            {
                Console.WriteLine(v);
            }
            foreach(int k in names.Keys)
            {
                Console.WriteLine(k);

            }



            string s1 = names[100];
            Console.WriteLine(s1);
            names.Remove(4);

            if(names.ContainsKey(30))
            {
                string s = names[30];
                Console.WriteLine(s);
            }
                





            /*
            List<int> marks = new List<int>();
            marks.Add(88);
            marks.Add(77);
            marks.Add(66);
            marks.Add(46);
            marks.Add(78);
            for (int c = 0; c < marks.Count; c++)
            {
                int i = marks[c];
                Console.WriteLine(i);
            }
            marks.Remove(66);
            marks[1] = 99;
            marks.Sort();// sorted in ascending order
            marks.Reverse();

            foreach(int m in marks)
            {
                Console.WriteLine(m);
            }
            */




            /*
            Test obj = new Test();
            int x = obj.call<int>(100);//generic function
            Console.WriteLine(x);
            string str = obj.call<string>("hello");
            Console.WriteLine(str);*/





            /*
            ArrayList names = new ArrayList();//arraylist
            Console.WriteLine(names.Count);
            names.Add("john");//adding array elements
            names.Add("sdd");// stored has object o="ssd";
            int i = 1000;
            names.Add(i);
            names[0] = "pooja";
            string s = names[0].ToString();
            for(int c=0;c<names.Count;c++)//fetch the array items in list
            {
                string str = names[c].ToString();
                Console.WriteLine(str);
            }
            foreach(string s1 in names)
            {
                Console.WriteLine(s1);
            }
            Console.WriteLine(names.Count);
            names.Remove("john");//removing the element in array
            names.RemoveAt(0);
            Console.WriteLine(names.Count);


    */
            Console.ReadLine();









        }
    }
}
