﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace console_calculation_dll
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the value of a");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the value of b");
            int b = Convert.ToInt32(Console.ReadLine());
            Testcal.Class1 dll = new Testcal.Class1();
            int sum = dll.add(a, b);
            int sub = dll.sub(a, b);
            int mul = dll.mult(a, b);
            int div = dll.div(a, b);
            Console.WriteLine("sum=" + sum);
            Console.WriteLine("sub" + sub);
            Console.WriteLine("multiplication=" + mul);
            Console.WriteLine("division=" + div);

            Console.ReadLine();




        }
    }
}
